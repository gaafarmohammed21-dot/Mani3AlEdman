package com.example.mani3aledman

import android.app.DatePickerDialog
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.time.LocalDate
import java.time.temporal.ChronoUnit
import java.util.Calendar

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.layoutDirection = android.view.View.LAYOUT_DIRECTION_RTL
        setContent { AppScreen() }
    }
}

@Composable
fun AppScreen() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("tracker", 0) }
    var startDate by remember {
        mutableStateOf(runCatching { LocalDate.parse(prefs.getString("start", null)) }.getOrNull())
    }
    var bestDays by remember { mutableIntStateOf(prefs.getInt("best", 0)) }
    var showResetDialog by remember { mutableStateOf(false) }
    var showStartPicker by remember { mutableStateOf(startDate == null) }

    val today = LocalDate.now()
    val currentDays = startDate?.let { ChronoUnit.DAYS.between(it, today).toInt().coerceAtLeast(0) } ?: 0
    val record = maxOf(bestDays, currentDays)

    fun saveStart(date: LocalDate) {
        startDate = date
        prefs.edit().putString("start", date.toString())
            .putInt("best", maxOf(bestDays, ChronoUnit.DAYS.between(date, today).toInt().coerceAtLeast(0)))
            .apply()
        bestDays = maxOf(bestDays, ChronoUnit.DAYS.between(date, today).toInt().coerceAtLeast(0))
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = androidx.compose.ui.graphics.Color(0xFF63D6A5),
            background = androidx.compose.ui.graphics.Color(0xFF101916),
            surface = androidx.compose.ui.graphics.Color(0xFF19241F)
        )
    ) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(Modifier.height(18.dp))
                Text("مانع للإدمان", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Text("خطوة صغيرة كل يوم", color = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.height(28.dp))

                Card(
                    Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("مدة التزامك الحالية", style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(12.dp))
                        Text("$currentDays", style = MaterialTheme.typography.displayLarge, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary)
                        Text(if (currentDays == 1) "يوم" else "أيام", style = MaterialTheme.typography.titleLarge)
                        Spacer(Modifier.height(8.dp))
                        Text(
                            startDate?.let { "بدأت في ${it.dayOfMonth}/${it.monthValue}/${it.year}" } ?: "حدد تاريخ البداية",
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Spacer(Modifier.height(16.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    StatCard("أفضل رقم", "$record يوم", Modifier.weight(1f))
                    StatCard("تاريخ اليوم", "${today.dayOfMonth}/${today.monthValue}/${today.year}", Modifier.weight(1f))
                }

                Spacer(Modifier.height(24.dp))
                Button(
                    onClick = {
                        val c = Calendar.getInstance()
                        DatePickerDialog(context, { _, y, m, d ->
                            saveStart(LocalDate.of(y, m + 1, d))
                        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
                    },
                    modifier = Modifier.fillMaxWidth().height(52.dp)
                ) { Text(if (startDate == null) "تحديد تاريخ البداية" else "تعديل تاريخ البداية") }

                Spacer(Modifier.height(10.dp))
                OutlinedButton(
                    onClick = { showResetDialog = true },
                    modifier = Modifier.fillMaxWidth().height(52.dp)
                ) { Text("تسجيل تعثّر وإعادة العدّاد") }

                Spacer(Modifier.height(22.dp))
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Column(Modifier.padding(16.dp)) {
                        Text("تذكير مهم", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.height(6.dp))
                        Text(
                            "التقدم مش سباق، وكل يوم فرصة جديدة. لو حصل تعثّر، اتعامل معاه بهدوء وتعلّم منه من غير لوم أو قسوة على نفسك.",
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
                Spacer(Modifier.height(18.dp))
                Text("بياناتك محفوظة على جهازك فقط.", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(24.dp))
            }
        }
    }

    if (showResetDialog) {
        AlertDialog(
            onDismissRequest = { showResetDialog = false },
            title = { Text("تسجيل تعثّر؟") },
            text = { Text("هيبدأ العدّاد من النهارده، مع الاحتفاظ بأفضل مدة حققتها. التقدم السابق يظل إنجازًا.") },
            confirmButton = {
                TextButton(onClick = {
                    if (startDate != null) bestDays = maxOf(bestDays, currentDays)
                    prefs.edit().putInt("best", maxOf(bestDays, currentDays))
                        .putString("start", today.toString()).apply()
                    startDate = today
                    showResetDialog = false
                }) { Text("تأكيد") }
            },
            dismissButton = { TextButton(onClick = { showResetDialog = false }) { Text("إلغاء") } }
        )
    }
}

@Composable
fun StatCard(title: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier, shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.fillMaxWidth().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(title, style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(8.dp))
            Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        }
    }
}
